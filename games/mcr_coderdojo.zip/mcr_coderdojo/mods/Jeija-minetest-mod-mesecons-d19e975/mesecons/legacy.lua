function mesecon:receptor_on(pos, rules)
	mesecon.receptor_on(pos, rules)
end

function mesecon:receptor_off(pos, rules)
	mesecon.receptor_off(pos, rules)
end
